function [data_eeg] = read_nexstim60channels_data(file_path) 

raw = load(file_path);              % load `.mat` file  

% create FieldTrip data structure 
data_eeg = [];
data_eeg.fsample = raw.srate;           % sampling frequency in Hz, single number
data_eeg.label = {raw.chlocs.labels}';  % names of channels 
data_eeg.trial = {raw.EEG'};            % actual trial time series  

trial_dimension = size(raw.EEG);
samples = 0:trial_dimension(1)-1;
data_eeg.time = {samples/data_eeg.fsample}; % time axis corresponding to trial.
data_eeg.sampleinfo = [1, trial_dimension(1)]; % 1 trial (no stimulus)
end 
