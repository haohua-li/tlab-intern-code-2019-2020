from scipy.io import loadmat
import numpy as np
import mne
import os
import matplotlib.pyplot as plt


# specify the input data name and read mat file
fp = os.path.join('data', 'H0048P(2).mat')
data = loadmat(fp)

# 
ch_names = np.concatenate(data['chlocs']['labels'][0]).tolist()
fsample = data['srate'].item(0)
Ntrial = data['EEG'].shape[0]
time_axis = np.arange(0, Ntrial, 1) / fsample
data_eeg = np.transpose(data['EEG'])
info = mne.create_info(ch_names=ch_names, sfreq=fsample, ch_types='eeg')

#
elec = data['channel_position']
montage = mne.channels.make_dig_montage(ch_pos=dict(zip(ch_names, elec)),
                                        coord_frame='head')
#
raw = mne.io.RawArray(data_eeg, info)
raw.set_montage(montage)

# Plot the montage of
layout_from_raw = mne.channels.make_eeg_layout(raw.info)
layout_from_raw.plot()

fig = montage.plot(kind='3d')
fig.gca().view_init(azim=70, elev=15)