%% Use HCTSA 
% use a small function from HCTSA, and check 
x = 1:10; 
try 
    x = ST_Length(x);   
catch 
    run('C:\Users\massw\Documents\GitHub\HCTSA\startup.m'); 
end
clear t x y hctsa_path 

%% 
TS_InspectQuality('summary'); 
