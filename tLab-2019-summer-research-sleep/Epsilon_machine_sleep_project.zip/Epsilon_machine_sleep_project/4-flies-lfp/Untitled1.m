% load HCTSA
x = 1:10; 
try 
    x = ST_Length(x);  
catch
    run('C:\Users\massw\Documents\GitHub\HCTSA\startup.m');
    % run('/home/haohual/ot95/haohua/bin/hctsa/startup.m'); 
end
clear x

% load flies data 
load('split2250_bipolarRerefType1_lineNoiseRemoved_postPuffpreStim.mat')

% select a particular fly, channel and condition 
channel_select = 15;  % from 1 to 15, bipolar reference. 
condition_select = 1; % condition 1 is awake, condition 2 is anaesthesia.
fly = 1;              % 13 flies in total.

% Sampling frequency is 1000 Hz, 8 trials. 
% Each trial lasts 2.25 seconds. 
% If full segment is 18 seconds (longest segment).
ch15_fly1_wake_data = fly_data(:, channel_select, :, fly, condition_select); 
ch15_fly1_wake_data = reshape(ch15_fly1_wake_data, [2250, 8]); 

% The first 4.5s segment 
numseg2_ch15_fly1_wake_data = reshape(ch15_fly1_wake_data(:, 1:2), [1, 2250*2]); 

% using HCTSA format 
timeSeriesData = { numseg2_ch15_fly1_wake_data };
labels = { 'LFP_fly1_chan15_seg2' }; 
keywords = { 'fly,seg2,channel_15,lfp' }; 
        
% Save these variables out to INP_test.mat:
save('INP_test.mat','timeSeriesData','labels','keywords');
% Initialize a new hctsa analysis using these data and the default feature library:
TS_init('INP_test.mat');

% ignore some master operations 
% https://hctsa-users.gitbook.io/hctsa-manual/calculating/working_with_hctsa_files
TS_local_clear_remove('HCTSA.mat', 'ops', TS_getIDs('posOnly','HCTSA.mat','ops'), 1);

% HCTSA compute results 
TS_compute;