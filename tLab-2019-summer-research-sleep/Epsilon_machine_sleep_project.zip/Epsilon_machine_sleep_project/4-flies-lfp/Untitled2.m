% load HCTSA
x = 1:10; 
try 
    x = ST_Length(x);  
catch 
    run('/home/haohual/ot95/haohua/bin/hctsa/startup.m'); 
end
clear x

% load flies data 
load('split2250_bipolarRerefType1_lineNoiseRemoved_postPuffpreStim.mat')

% select a particular fly, channel and condition 
channel_select = 15;  % from 1 to 15, bipolar reference. 
condition_select = 1; % condition 1 is awake, condition 2 is anaesthesia.
fly = 1;              % 13 flies in total.

% Sampling frequency is 1000 Hz, 8 trials. 
% Each trial lasts 2.25 seconds. 
% If full segment is 18 seconds (longest segment).
ch15_fly1_wake_data = fly_data(:, channel_select, :, fly, condition_select); 
ch15_fly1_wake_data = reshape(ch15_fly1_wake_data, [2250, 8]); 

% The first 2.25s segment 
numseg1_ch15_fly1_wake_data = reshape(ch15_fly1_wake_data(:, 1), [1, 2250]);
% The first 4.5s segment 
numseg2_ch15_fly1_wake_data = reshape(ch15_fly1_wake_data(:, 1:2), [1, 2250*2]); 
% The first 9s segment 
numseg4_ch15_fly1_wake_data = reshape(ch15_fly1_wake_data(:, 1:4), [1, 2250*4]);
% The first 18s segment 
numsep8_ch15_fly1_wake_data = reshape(ch15_fly1_wake_data(:, 1:8), [1, 2250*8]);

% using HCTSA format 
timeSeriesData = { numseg1_ch15_fly1_wake_data, numseg2_ch15_fly1_wake_data, ...
                   numseg4_ch15_fly1_wake_data, numsep8_ch15_fly1_wake_data};
labels = {'LFP_fly1_chan15_seg1', 'LFP_fly1_chan15_seg2', ...
          'LFP_fly1_chan15_seg4', 'LFP_fly1_chan15_seg8'}; 
keywords = {'fly1,seg1,channel_15,lfp','fly,seg2,channel_15,lfp', ...
            'fly1,seg4,channel_15,lfp','fly,seg8,channel_15,lfp'}; % comma-delimited keywords for each time series
        
% Save these variables out to INP_test.mat:
save('INP_test.mat','timeSeriesData','labels','keywords');
% Initialize a new hctsa analysis using these data and the default feature library:
TS_init('INP_test.mat');
TS_compute;