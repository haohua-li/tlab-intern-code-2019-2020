% Using the GNU Compiler Collection (GCC)
% https://access.redhat.com/documentation/en-US/Red_Hat_Enterprise_Linux/4/html/Using_the_GNU_Compiler_Collection/overall-options.html

% mex savefiles.cpp



c = 'Hello World!'; 

% 
file_name = 'test1.txt'; 
full_path = fullfile(pwd, 'outputs', file_name); 

% Escape the backslashes in the full path string, to keep compatible with
% Windows operating system. 
if ispc
    full_path = strrep(full_path,'\','\\'); 
end

savefiles(full_path, file_name, c); 

