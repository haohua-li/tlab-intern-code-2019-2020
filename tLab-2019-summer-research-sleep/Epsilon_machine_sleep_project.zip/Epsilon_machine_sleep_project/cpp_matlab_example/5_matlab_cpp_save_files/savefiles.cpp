#include <iostream>
#include "mex.h"
#include <string.h>
#include <fstream>    
using namespace std; 

void save_text(char filename[], char content[]){
    // create file stream
    ofstream outData(filename, ios::out);

    //open output file, if unsuccessful set boolean return value
    if (!outData){
        cerr << " the results output file cannot be opened " << endl; 
    }else{
        outData << content << endl;
    }

    // finish writing 
    outData.close();
    return;
}

void mexFunction(int nlhs, mxArray* plhs[], int nrhs, const mxArray* prhs[]) {
    // savefiles('\Users\massw\Downloads\hello.txt', 'hello', 'Hello World!'); s

    /* Check for proper number of arguments */
    if (nrhs != 3) {
        mexErrMsgIdAndTxt("MATLAB:mexadd:nargin", "MEXCPP requires only one input arguments.");
    }
    if (nlhs > 0) {
        mexErrMsgIdAndTxt( "MATLAB:revord:maxlhs", "Too many output arguments.");
    }

    /* input must be a string */
    if (mxIsChar(prhs[0]) != 1 &&  mxIsChar(prhs[1]) != 1 && mxIsChar(prhs[2]) != 1)
      mexErrMsgIdAndTxt( "MATLAB:revord:inputNotString", "Inputs must be a string.");

    /* input must be a row vector */
    if (mxGetM(prhs[0]) != 1 && mxGetM(prhs[1]) != 1 && mxGetM(prhs[2]) != 1)
      mexErrMsgIdAndTxt( "MATLAB:revord:inputNotVector", "Inputs must be a row vector.");

    /* convert matlab mxArray input to a string, then save */
    char *full_path = mxArrayToString(prhs[0]); 
    char *file_name = mxArrayToString(prhs[1]); 
    char *content = mxArrayToString(prhs[2]);

    
    /* */  
    save_text(full_path, content); 
    mxFree(full_path);
    mxFree(file_name); 
    mxFree(content);

    return;
}