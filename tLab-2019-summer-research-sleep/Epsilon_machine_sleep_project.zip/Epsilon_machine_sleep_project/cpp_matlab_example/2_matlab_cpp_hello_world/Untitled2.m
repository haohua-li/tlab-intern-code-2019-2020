% Using the GNU Compiler Collection (GCC)
% https://access.redhat.com/documentation/en-US/Red_Hat_Enterprise_Linux/4/html/Using_the_GNU_Compiler_Collection/overall-options.html

try
    ans = mexapp(5,6)
catch ME
    switch ME.identifier
        case 'MATLAB:UndefinedFunction'
            error('Function is undefined. Run "make.m" to compile first and then run again.');
        otherwise
            rethrow(ME)
    end
end