#include <iostream>
#include "mex.h"


double mexadd(double num1, double num2){
    return num1 + num2; 
}

/* 
    The calling style : 
       - `add(num1<vector>, num2<vector>)`

    mexFunction: the gateway function. 
       - nlhs : number of outputs (left hand side)
       - plhs : outputs in the left hand side 
       - 
       - nrhs : number of inputs (right hand side)
       - prhs : inputs/arguments in the right hand side 
       
       https://books.google.com.au/books?id=hI14CgAAQBAJ&pg=PA222&lpg=PA222&dq=mxGetm+number&source=bl&ots=H_yy7aQIdB&sig=ACfU3U1-Fv1kCBOtSZloJ7Y9c_fYnhZRGA&hl=zh-CN&sa=X&ved=2ahUKEwj-qYnr-LjmAhXGyzgGHU0zDbgQ6AEwBXoECAoQAQ#v=onepage&q=mxGetm%20number&f=false
*/
void mexFunction(int nlhs, mxArray* plhs[], int nrhs, const mxArray* prhs[]) {

    /* Check for proper number of arguments */
    if (nrhs != 2) {
        mexErrMsgIdAndTxt("MATLAB:mexadd:nargin", "MEXCPP requires two input arguments.");
    }
    if (nlhs != 1) {
        mexErrMsgIdAndTxt("MATLAB:mexadd:nargout", "MEXCPP requires one output argument.");
    }

    /* Check if the input is of proper type */ 
    // Scalar, vector, matrix 
    if (!mxIsDouble(prhs[0]) || !mxIsScalar(prhs[0])) { 
        mexErrMsgIdAndTxt("MATLAB:mexadd:typeargin", "First argument has to be double scalar.");
    }
    if (!mxIsDouble(prhs[1]) || !mxIsScalar(prhs[1])) { 
        mexErrMsgIdAndTxt("MATLAB:mexadd:typeargin", "Second argument has to be double scalar.");
    }

    /* Acquire pointers to the input data */
    double* vin1 = mxGetPr(prhs[0]);
    double* vin2 = mxGetPr(prhs[1]);

    /* Execute the operation */ 
    double r = mexadd(*vin1, *vin2);

    /* Print the output */
    mexPrintf("result is %g:\n", r); 

    /* output the results */ 
    plhs[0] = mxCreateNumericMatrix(1, 1, mxDOUBLE_CLASS, mxREAL); // memory-allocation 
    double* ans = (double*) mxGetData(plhs[0]); // acquire the pointer 
    *ans = r; // load result to ans

}
