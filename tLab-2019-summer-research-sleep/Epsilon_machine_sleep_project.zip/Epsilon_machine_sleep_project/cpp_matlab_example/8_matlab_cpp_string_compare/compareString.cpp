#include "mex.h"

void mexFunction(int nlhs, mxArray* plhs[], int nrhs, const mxArray* prhs[]) {
    char *x = mxArrayToString(prhs[0]); 
    char *y = mxArrayToString(prhs[1]); 


    mxFree(x);
    mxFree(y); 
    return;
}