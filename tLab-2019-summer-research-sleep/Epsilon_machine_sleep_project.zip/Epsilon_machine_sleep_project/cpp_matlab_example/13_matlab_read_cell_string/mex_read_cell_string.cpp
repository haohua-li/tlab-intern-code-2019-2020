#include <iostream>
#include "mex.h"

void mexFunction(int nlhs, mxArray* plhs[], int nrhs, const mxArray* prhs[]) {

    if (!mxIsCell(prhs[0]) && !mxIsChar(prhs[0])){
        mexErrMsgTxt("The input data must be a cell array or a string.  See https://github.com/randoruf/CSSR-Matlab for more help.");
    }else{
        std::cout << "Correct Inputs!!!!" << std::endl;
    } 


    return; 
}