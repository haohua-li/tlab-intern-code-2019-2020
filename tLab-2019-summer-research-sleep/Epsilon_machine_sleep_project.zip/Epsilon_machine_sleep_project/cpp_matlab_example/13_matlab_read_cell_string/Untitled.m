% mex mex_read_cell_string.cpp

mex_read_cell_string('fuck.txt')
mex_read_cell_string({'154654654';'16546546464'})