#include "mex.h"

void mexFunction(int nlhs, mxArray* plhs[], int nrhs, const mxArray* prhs[]) {
    
    mexErrMsgTxt("Fatal error will stop matlab!"); 
    
    return;
}