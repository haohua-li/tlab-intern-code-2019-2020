//
//  main.cpp
//  11_cpp_text_buffer
//
//  Created by Randolph Li on 31/12/1 R.
//  Copyright © 1 Randolph. All rights reserved.
//

#include <iostream>
#include <fstream>
#define MAX_LINE_SIZE 5
using namespace std;

int main(int argc, const char * argv[]) {
    
    /* read a text file called 'text1.txt' */
    char dataFile[] = "text1.txt";
    ifstream inData(dataFile, ios::in);
    char* buffer = new char[MAX_LINE_SIZE + 1];
    inData.getline(buffer, MAX_LINE_SIZE);
    
    /* see how C program read the text file and print out*/
    std::cout << buffer << std::endl;
    
    /* clean up */
    delete [] buffer;
    
    return 0;
}
