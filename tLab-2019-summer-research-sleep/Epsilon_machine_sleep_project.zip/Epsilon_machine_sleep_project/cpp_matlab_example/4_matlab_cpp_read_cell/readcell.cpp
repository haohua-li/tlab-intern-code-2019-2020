#include <iostream>
#include "mex.h"
#include <string.h>

void printstring(char *str, int strLen){
    int i; 
    for (i = 0; i<strLen; i++){
        std::cout << str[i] << std::endl;  
    }
    std::cout << "-----" << std::endl; 
    return; 
}

void mexFunction(int nlhs, mxArray* plhs[], int nrhs, const mxArray* prhs[]) {

    /* Check for proper number of arguments */
    if (nrhs != 1) {
        mexErrMsgIdAndTxt("MATLAB:mexadd:nargin", "MEXCPP requires only one input arguments.");
    }
    if (nlhs > 0) {
        mexErrMsgIdAndTxt( "MATLAB:revord:maxlhs", "Too many output arguments.");
    }
    
    mwSize n;
    mwIndex i;
    char* m_alpha; 
    
    if (nrhs != 1 || !mxIsCell (prhs[0]))
      mexErrMsgTxt ("ARG1 must be a cell");

    n = mxGetNumberOfElements (prhs[0]);
    for (i = 0; i < n; i++){
      m_alpha = mxArrayToString(mxGetCell(prhs[0], i));
      if(m_alpha == NULL) 
      mexErrMsgIdAndTxt( "MATLAB:revord:conversionFailed","Could not convert input to string.");
      /* print out the input string character by charater*/
      printstring(m_alpha, strlen(m_alpha));
      /* clear up */
      mxFree(m_alpha); 
    }

    return;
}