% Using the GNU Compiler Collection (GCC)
% https://access.redhat.com/documentation/en-US/Red_Hat_Enterprise_Linux/4/html/Using_the_GNU_Compiler_Collection/overall-options.html

% mex readcell.cpp


a = { '0100111'; 
      '11101' ; 
      '1010001'}; 
  
a(4) = {'000111001111'};
