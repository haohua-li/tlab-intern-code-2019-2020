#include <iostream>
#include "mex.h"
#include "matrix.h"

void mexFunction(int nlhs, mxArray* plhs[], int nrhs, const mxArray* prhs[]) {

    // create a array !
    int N = 10; 
    plhs[0] = mxCreateNumericMatrix(1, N, mxDOUBLE_CLASS, mxREAL); 
    double* ans = (double*) mxGetData(plhs[0]); 
    // 
    for (int i = 0; i < N; i++){
        ans[i] = i; 
    }

    return; 
}