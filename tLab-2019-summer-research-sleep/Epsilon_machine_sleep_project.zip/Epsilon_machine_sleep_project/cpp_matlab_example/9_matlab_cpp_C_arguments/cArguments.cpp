#include <iostream>
#include "mex.h"
using namespace std;


int main(int argc, char *argv[]) {
    
    std::cout << "-------------" << std::endl; 

    std::cout << "Number of arguments: " << argc << std::endl;

    for (int i = 0; i < argc ; i++){
        std::cout << argv[i] << " "; 
    }
    std::cout << std::endl; 

    return 0; 
}

void mexFunction(int nlhs, mxArray* plhs[], int nrhs, const mxArray* prhs[]) {
    // convert Matlab arguments to C arguments.
    char **argv = new char*[nrhs];  
    for (int i = 0; i < nrhs ; i++){
        argv[i] = mxArrayToString(prhs[i]); 
    }

    // do something.... here
    main(nrhs, argv); 

    // clean up 
    for (int i = 0; i < nrhs; i++){
        mxFree(argv[i]); 
    }

    return ;
}