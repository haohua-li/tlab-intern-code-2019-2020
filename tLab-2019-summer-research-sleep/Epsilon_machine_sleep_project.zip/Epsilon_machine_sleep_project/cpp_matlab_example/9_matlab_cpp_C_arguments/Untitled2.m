% Using the GNU Compiler Collection (GCC)
% https://access.redhat.com/documentation/en-US/Red_Hat_Enterprise_Linux/4/html/Using_the_GNU_Compiler_Collection/overall-options.html

clear;clc;
 
mex -output CSSR cArguments.cpp

CSSR('./CSSR', 'a.txt', 'd.txt', '3', '-s', '-m', '-ch')
CSSR('./CSSR', 'a.txt', 'd.txt', '3', '-s', '-m')
CSSR('./CSSR', 'a.txt', 'd.txt', '3', '-s')

