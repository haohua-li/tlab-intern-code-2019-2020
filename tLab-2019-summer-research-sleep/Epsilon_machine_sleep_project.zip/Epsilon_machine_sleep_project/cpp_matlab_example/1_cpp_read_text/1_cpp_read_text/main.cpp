#include <iostream>
#include <fstream>
#include <string>
using namespace std;

int main(int argc, const char * argv[]) {
    // initialization
    cout << "Hello World!" << endl;
    string s;
    
    // ask the user for the name of file
    cout << "Please enter filename: " << endl;
    cin >> s;
    
    // create file stream
    ifstream inData(s.c_str(), ios::in);
    long long int size;
    char c;
    int offset = 1;
                
    // check if data file is open
    if (!inData.is_open()){
        cerr << "The data file cannot be opened" << endl;
        exit(1);
    }
    // otherwise read in data until end of life
    else{
        // get length of file
        inData.seekg(0, ios::end);
        size = inData.tellg();
        inData.seekg(0, ios::beg);
        
        // read content from the file
        char* m_data = new char[size+1];
        inData.get(m_data, size+1, '\0');
        cout << "Initial text size is " << size << "\n";
        
        // deal with newline symbol
        cout << "------------------" << endl;
        

        if (m_data[size - 2] == '\n') {
          offset = 2;
        }
        else if (m_data[size - 1] == '\n') {
          offset = 1;
        }
        else if (isalnum(m_data[size - 1])) {
          offset = 0;
        }
        
        cout << "Offset is " << offset << "\n";
        
        c = m_data[size-offset];
        cout << "ASCII value of " << c <<" is :  " << (int)c << "\n";
        
        m_data[size - offset] = '\0';
        int m_alphaSize = strlen(m_data);
        cout << "The size of file is " << m_alphaSize << " \n.";
        
        
        cout << "------------------" << endl;
        
        
        
        
    }
        
        
    inData.close();
    return 0;
}
