#include "mex.h"

int main(){
    mexPrintf("Hello World!");
    return 1;
}

void mexFunction(int nlhs, mxArray* plhs[], int nrhs, const mxArray* prhs[]) {
    main(); 
    return;
}