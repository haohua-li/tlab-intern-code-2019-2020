% Using the GNU Compiler Collection (GCC)
% https://access.redhat.com/documentation/en-US/Red_Hat_Enterprise_Linux/4/html/Using_the_GNU_Compiler_Collection/overall-options.html

clear;clc;
 
% mex mexgetString.cpp

mexgetString('kimi')
mexgetString('imamo')