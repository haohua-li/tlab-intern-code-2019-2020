#include <iostream>
#include "mex.h"
using namespace std;

void mexFunction(int nlhs, mxArray* plhs[], int nrhs, const mxArray* prhs[]) {
    /* Check input type and the number of argument */
    if (nrhs != 1){
        mexErrMsgIdAndTxt("MATLAB:mexgetString:rhs","This function requires only 1 input.");
    }

    if (!mxIsChar(prhs[0])){
        mexErrMsgIdAndTxt("mexgetString:InputString", "Input must be a string!"); 
    }

    // https://au.mathworks.com/help/matlab/matlab_external/c-matrix-api-string-handling-functions.html
    // http://www.math.clemson.edu/~warner/M360/Matlab/mxGetString.html
    
    /* convert the Matlab mxArray to an array of characters(string in C-style) */ 
    char *buf = NULL; 
    int strlen = 5; 
    int buflen = strlen + 1; 
    buf = (char*) mxCalloc(buflen,sizeof(char));

    char *full_text = NULL; 
    // Handle the case that Matlab fail to process string input (for example, 
    // run out of memory?).
    mexPrintf("\nThe input string is : \n");
    if (mxGetString(prhs[0], buf, buflen) == 0) {
        mexPrintf("\t - with buffer:  %s\n", buf);
    }
    else { 
        mexErrMsgIdAndTxt("MyProg:ConvertString", "Could not convert string data.");
    } 
    
    /* fully convert the Matlab string input */
    full_text = mxArrayToString(prhs[0]);
    if (full_text == NULL){
        mexErrMsgIdAndTxt("MyProg:ConvertString", "Could not convert string data.");
    }else{
        mexPrintf("\t - fully extract:  %s\n", full_text);
    }

    // clean up 
    mxFree(buf);
    mxFree(full_text);

}