#include <iostream>
#include "mex.h"
#include <string.h>

void printstring(char *str, int strLen){
    int i; 
    for (i = 0; i<strLen; i++){
        std::cout << str[i] << std::endl;  
    }
    return; 
}

void mexFunction(int nlhs, mxArray* plhs[], int nrhs, const mxArray* prhs[]) {

    /* Check for proper number of arguments */
    if (nrhs != 1) {
        mexErrMsgIdAndTxt("MATLAB:mexadd:nargin", "MEXCPP requires only one input arguments.");
    }
    if (nlhs > 0) {
        mexErrMsgIdAndTxt( "MATLAB:revord:maxlhs", "Too many output arguments.");
    }

    /* input must be a string */
    if (mxIsChar(prhs[0]) != 1)
      mexErrMsgIdAndTxt( "MATLAB:revord:inputNotString", "Input must be a string.");

    /* input must be a row vector */
    if (mxGetM(prhs[0]) != 1)
      mexErrMsgIdAndTxt( "MATLAB:revord:inputNotVector", "Input must be a row vector.");

    /* get the length of the input string */
    int buflen = (mxGetM(prhs[0]) * mxGetN(prhs[0])) + 1;
    char* m_alpha; 

    /* prhs[0] is mxArray type, be converted to char types*/ 
    m_alpha = mxArrayToString(prhs[0]);
    if(m_alpha == NULL) 
      mexErrMsgIdAndTxt( "MATLAB:revord:conversionFailed","Could not convert input to string.");

    /* print out the input string character by charater*/
    printstring(m_alpha, strlen(m_alpha));

    /* clear up */
    mxFree(m_alpha); 
    
    return;
}