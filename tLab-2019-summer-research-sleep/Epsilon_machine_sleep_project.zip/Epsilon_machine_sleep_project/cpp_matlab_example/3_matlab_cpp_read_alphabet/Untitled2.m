% Using the GNU Compiler Collection (GCC)
% https://access.redhat.com/documentation/en-US/Red_Hat_Enterprise_Linux/4/html/Using_the_GNU_Compiler_Collection/overall-options.html

% mex readalphabet.cpp

a = [0, 1, 0, 0, 1, 1, 1];
b = char.empty(0, length(a)); 
for i = 1:length(a) 
    b(i) = int2str(a(i)); 
end


c = { '0100111'; 
      '11101' ; 
      '1010001'}; 
[r,~] = size(c); 


      