%% set up the running environment 
clc; clear; 
addpath(genpath('C:\Users\massw\Documents\MATLAB\spm12'));
iFile_name = '217'; 

%% Noise filtering 
fD_name = ['SSP/spm_EEG/filtered_EEG/ffMS' iFile_name '.mat']; 
if ~isfile(fD_name)
    % load raw data into variables  
    D = spm_eeg_load(['SSP/spm_EEG/MS' iFile_name '.mat']); 
    run('filter_noise.m')
    % clean the directory (SPM toolbox will produce 'fMSxxx.mat', 'ffMSxxx.mat' and 'fffMSxxx.mat' in the same directory)
    % but 'fMSxxx.mat', 'ffMAxxx.mat' are unwanted. and 'fffMSxxx.mat' should appear 
    movefile(['SSP/spm_EEG/ffMS' iFile_name '.mat'], 'SSP/spm_EEG/filtered_EEG');
    movefile(['SSP/spm_EEG/ffMS' iFile_name '.dat'], 'SSP/spm_EEG/filtered_EEG');
    % remove the unused files 
    delete(['SSP/spm_EEG/fMS' iFile_name '.mat']); 
    delete(['SSP/spm_EEG/fMS' iFile_name '.dat']); 
end
    
%% Data Segmentation 
D_stage_name = ['SSP/spm_EEG/stages_EEG/ffMS' iFile_name '_stages.mat']; 
if ~isfile(D_stage_name)
    % load the filtered EEG data 
    D = spm_eeg_load(['SSP/spm_EEG/filtered_EEG/ffMS' iFile_name '.mat']); 
    S = load(['SSP/sleep_scoring/sleepScoring3_S' iFile_name '.mat']); 
    run('data_segmentation.m')
else 
    load(D_stage_name)
end 
disp('Finished Segmentiong')

%% EEG Montage
