%% filtering noises 

% The EEG EOG signals were high-pass filtered >0.1 Hz
S = []; 
S.D = D; 
S.type = 'butterworth'; S.order = 5; S.dir = 'twopass'; 
S.band = 'high';
S.freq = [0.5];
D = spm_eeg_filter(S);

% then low-pass filtered <40 Hz (two-pass Butterworth filters at the fifth order).
S = []; 
S.D = D; 
S.type = 'butterworth'; S.order = 5; S.dir = 'twopass'; 
S.band = 'low';
S.freq = [40];
D = spm_eeg_filter(S);


% (since we ignore the voltage/potential over 40Hz, the 50Hz line noises 
% are also filtered.)

% % A notch-filter (second order Infinite Impulse Response filter) ~50 Hz was used on all channels to reduce line-noise.
% S = []; 
% S.D = D; 
% S.type = 'butterworth'; S.order = 5; S.dir = 'twopass'; 
% S.band = 'stop';
% S.freq = [45 55];
% D = spm_eeg_filter(S);

%% Just for testing, ignore all 

% y1 = D(4, :, 1); 
% figure(1), plot(D.time(1:200), y1(1:200))
% title('Channal 4 after fitering ')
% xlabel('Time')
% ylabel('EEG volatge')

% y2 = D(4, :, 1); 
% figure(2), plot(D.time(1:200), y2(1:200)) 
% title('Channal 4 before filtering' )
% xlabel('Time')
% ylabel('EEG volatge')