%% Data segmentation 

% to seperate the sleep data based on the sleep scoring 
%    - each segment may has 20x200 discrete points (as sampling frequency is 200 Hz), 
%           and the duration of each segment is 20s  
%    - (But since artifacts, the actual size of each segement may be less than 4,000. )
%    - each segment is stored in a seperatd file. 

%___________________________________________________________________________________________

%% Cut data based on sleep scoring 
% 0: wake; 1: NREM1; 2: NREM2; 3: NREM3 and 5: REM sleep
f = 200; % sampling frequency 
h = 20; % the duration of each sleep stage (20 seconds) 

% number of data points 
N_stages = length(S.hypnogram); 
sleep_scoring_length = h * f; 
N_samples = size(D, 2); 

% cut off the tail
if f*(h*N_stages) > N_samples
   N_stages = N_stages - 1;  
end

% pre-allocate memory for eeg activities 
wake_activity = zeros(N_stages, 26, sleep_scoring_length); 
n1_activity = zeros(N_stages, 26, sleep_scoring_length); 
n2_activity = zeros(N_stages, 26, sleep_scoring_length); 
n3_activity = zeros(N_stages, 26, sleep_scoring_length); 
rem_activity = zeros(N_stages, 26, sleep_scoring_length); 

% to count the number of data points 
count_wake = 0; 
count_n1 = 0; 
count_n2 = 0; 
count_n3 = 0; 
count_rem = 0; 

% to cut the EEG into wake, N1, N2, N3 and REM segments 
for i = 1:N_stages
    switch S.hypnogram(i) 
        case 0 
            wake_activity(count_wake+1, :, :) = D(:, f*h*(i-1)+1:f*h*i, 1); 
            % D(:, f*h*(i-1)+1:f*h*i, 1) = 1; % just for testing, don't use
            count_wake = count_wake + 1; 
        case 1 
            n1_activity(count_n1+1,:, :) = D(:, f*h*(i-1)+1:f*h*i, 1);
            count_n1 = count_n1 + 1;
        case 2 
            n2_activity(count_n2+1, :, :) = D(:, f*h*(i-1)+1:f*h*i, 1);
            count_n2 = count_n2 + 1;
        case 3 
            n3_activity(count_n3+1, :, :) = D(:, f*h*(i-1)+1:f*h*i, 1); 
            count_n3 = count_n3 + 1;
        case 5
            rem_activity(count_rem+1, :, :) = D(:, f*h*(i-1)+1:f*h*i, 1); 
            count_rem = count_rem + 1;
        otherwise
            disp('Exception: epochs with artefacts')
    end
end 

% truncate 
wake_activity = wake_activity(1:count_wake, :, :); 
n1_activity = n1_activity(1:count_n1, :, :); 
n2_activity = n2_activity(1:count_n2, :, :); 
n3_activity = n3_activity(1:count_n3, :, :); 
rem_activity = rem_activity(1:count_rem, :, :); 

% channel information 
channels_info =  {'EOG left','EOG right','Fp1','C3','O1','Fp2','C4','O2','T3','T4','F3','F4','P3','P4','F7','F8','T5','T6','Fz','Cz','Pz','ECG','EMG chin','EMG right','EMG left','DIN'}';


% save cutted results to a directory/folder.
fp = sprintf('SSP/spm_EEG/stages_EEG/ffMS%s_stages.mat', iFile_name); 
save(fp, 'wake_activity', 'n1_activity', 'n2_activity', 'n3_activity', 'rem_activity', 'channels_info');