function i = find_channel_index(c)
t = {'EOG left','EOG right','Fp1','C3','O1','Fp2','C4','O2','T3','T4','F3','F4','P3','P4','F7','F8','T5','T6','Fz','Cz','Pz','ECG','EMG chin','EMG right','EMG left','DIN'};
i = match_str(t,c); 
end 