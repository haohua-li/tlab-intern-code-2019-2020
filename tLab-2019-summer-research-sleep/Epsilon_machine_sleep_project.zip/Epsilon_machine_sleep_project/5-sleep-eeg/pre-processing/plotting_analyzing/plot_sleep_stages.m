%% plot 
take_until = 20*(20*200); 

figure(1) 
e = length(wake_activity); 
min_until = e; 
% e = take_until;
plot(1:e, wake_activity(channel_index, 1:e)) 
title(strcat(channel_name, ' electrode in Wake stage'))
xlabel('sample(s)')
ylabel('Voltage (muV)')

figure(2)
e = length(n1_activity); 
if min_until > e
    min_until = e; 
end 
% e = take_until;
plot(1:e, n1_activity(channel_index, 1:e)) 
title(strcat(channel_name, ' electrode in N1 stage'))
xlabel('sample(s)')
ylabel('Voltage (muV)')

figure(3)
e = length(n2_activity); 
if min_until > e
    min_until = e; 
end 
% e = take_until;
plot(1:e, n2_activity(channel_index, 1:e)) 
title(strcat(channel_name, ' electrode in N2 stage'))
xlabel('sample(s)')
ylabel('Voltage (muV)')

figure(4)
e = length(n3_activity); 
if min_until > e
    min_until = e; 
end 
% e = take_until;
plot(1:e, n3_activity(channel_index, 1:e)) 
title(strcat(channel_name, ' electrode in N3 stage'))
xlabel('sample(s)')
ylabel('Voltage (muV)')

figure(5)
e = length(rem_activity); 
if min_until > e
    min_until = e; 
end 
% e = take_until;
plot(1:e, rem_activity(channel_index, 1:e)) 
title(strcat(channel_name, ' electrode in REM stage'))
xlabel('sample(s)')
ylabel('Voltage (muV)')


figure(6)
e = min_until; 
plot(1:e, wake_activity(channel_index, 1:e), ... 
     1:e, n1_activity(channel_index, 1:e), ... 
     1:e, n2_activity(channel_index, 1:e), ...
     1:e, n3_activity(channel_index, 1:e), ...
     1:e, rem_activity(channel_index, 1:e));  
title(strcat(channel_name, ' electrode in REM stage'))
legend('Wake', 'N1', 'N2', 'N3', 'REM')
xlabel('sample(s)')
ylabel('Voltage (muV)')


figure(7)
e = min_until; 
plot(1:e, wake_activity(20, 1:e), ...
     1:e, wake_activity(21, 1:e), ...
     1:e, wake_activity(19, 1:e)) 
title('Cz, Fz and Pz electrode in Wake stage')
legend('Cz', 'Fz', 'Pz')
xlabel('sample(s)')
ylabel('Voltage (muV)')
