
iFile_name = '216'; 
D = spm_eeg_load(['../SSP/spm_EEG/MS' iFile_name '.mat']); 
fD = spm_eeg_load(['../SSP/spm_EEG/filtered_EEG/ffMS' iFile_name '.mat']);

Fs = 200;                % Sampling frequency                    
T = 1/Fs;                % Sampling period       
L = 6318000;             % Length of signal

y = D(find_channel_index('Cz'),:,1);

%% Compute the FFT of the signal 
Y = fft(y);     % to frequency domain 
% Note that FFT is two-sided spectrum
% But two sides are symmetry... 

%% 
% Compute the two-sided spectrum P2. 
% Then compute the single-sided spectrum P1 based on P2 and the even-valued signal length L.
P2 = abs(Y/L);
P1 = P2(1:L/2+1);
P1(2:end-1) = 2*P1(2:end-1);

%% 
f = Fs*(0:(L/2))/L;
plot(f,P1) 
title('Single-Sided Amplitude Spectrum of X(t)')
xlabel('f (Hz)')
ylabel('|P1(f)|')



