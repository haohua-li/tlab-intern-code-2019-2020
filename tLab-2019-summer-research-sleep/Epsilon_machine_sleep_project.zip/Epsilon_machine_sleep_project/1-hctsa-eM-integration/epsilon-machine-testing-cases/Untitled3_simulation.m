%% Create random Markov chain (or namely Epsilon machine)
rng(1); % For reproducibility
num_states = 6; 
mc = mcmix(num_states);
figure(1);
graphplot(mc,'ColorEdges',true);

%% Simulation of Statistical Complexity 
disp('Start to simulate.......')
numSteps = 8000;  % how many times to execute the same random process.  
X = simulate(mc,numSteps); 
disp('Simulation finished. ')
indata = char(X' + 64);
% clipboard('copy',indata) 

disp('Start to CSSR.......')
d_file = 'markov_random_process1.txt';
fp = fopen(d_file, 'w'); 
fprintf(fp,'%s',indata);
fclose(fp);

% using CSSR to compute statistical complexity
disp('CSSR finished.')
