
a = '01'; 

fp = 'sleep_data1.txt';
d_txt = fopen(fp, 'r');
d = fscanf(d_txt, '%c')
fclose(d_txt);

CSSR('./CSSR', a, d, '5', '0.005')