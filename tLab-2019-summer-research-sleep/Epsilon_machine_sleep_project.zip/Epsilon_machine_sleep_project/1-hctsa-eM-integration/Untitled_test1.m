clc;clear;
% load HCTSA
x = 1:10; 
try 
    ST_Length(x); 
catch 
    hctsa_startup_file = fullfile('..', '..', '..', 'HCTSA', 'startup.m');
    run(hctsa_startup_file)
end
clear t hctsa_startup_file 

% load a time series 
%% HCTSA's showtime 
% select a participant whose EEG is raw_data 
subject_id = 'H0090W'; 
data_path = fullfile('..', '2-anesthesia-eeg', 'data', 'restEEG_HealthySubjects');
data_file = strcat(subject_id, '.mat');   
raw_data = load(fullfile(data_path, data_file));
clear data_file data_path

% select a channel, and a segment 
fsample = 1450; 
take_until = [0, 4]; % take until 4s... 
channel_selct = 16; 

% specify the input time series with some information. 
timeSeriesData = raw_data.EEG(take_until(1)*fsample+1 : take_until(2)*fsample, channel_selct)'; 
labels = {strcat('EEG', num2str(channel_selct))}; 
keywords = {strcat(subject_id, ',wake,', labels{1})};
save('INP_test.mat','timeSeriesData','labels','keywords'); 

% Initialize a new hctsa analysis using these data and the default feature library:
TS_init('INP_test.mat');

% Conduct HCTSA 
TS_compute(); 

%% 
