#!python
#!/usr/bin/env python
from scipy.io import loadmat
import numpy as np
import mne
import os

# specify the input data name and read mat file
fp = os.path.join('..', 'data', 'restEEG_HealthySubjects', 'H0048P.mat')
raw = loadmat(fp)

# sampling frequency
fsample = raw['srate'].item(0)
# read a list channel name from mat
ch_names = np.concatenate(raw['chlocs']['labels'][0]).tolist()
ch_types = 'eeg'
# create time axis
Ntrial = raw['EEG'].shape[0]
time_axis = np.arange(0, Ntrial, 1) / fsample
# actual trial time series
data_eeg = np.transpose(raw['EEG'])

# create MNE object
info = mne.create_info(ch_names=ch_names, sfreq=fsample, ch_types=ch_types)
raw = mne.io.RawArray(data_eeg, info)

# Scaling of the figure.
# It is also possible to auto-compute scalings
scalings = 'auto'  # Could also pass a dictionary with some value == 'auto'
raw.plot(n_channels=60, scalings=scalings, title='Auto-scaled Data from arrays',
         show=True, block=True)

fig = raw.plot_psd(tmax=np.inf, fmin=1, fmax=500, average=True)


