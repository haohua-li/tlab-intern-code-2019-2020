clear;clc; 
%% import FieldTrip toolbox into Matlab 
p = fullfile(userpath, 'fieldtrip-20200115'); 
% add the fieldtrip path to the current session.
% (IMPORTANTA: Don't set the "Set Path" in HOME tab, 
%              it will pollute MATLAB's Library. Run this script every time)
addpath(p);
%% convert .mat format to FieldTrip format 
data_eeg = read_nexstim60channels_data('../data/restEEG_HealthySubjects/H0010P.mat');
%% plot all channels 
cfg = [];
cfg.viewmode = 'vertical';
artfct       = ft_databrowser(cfg, data_eeg)